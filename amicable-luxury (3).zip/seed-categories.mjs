import mysql from 'mysql2/promise';

const categories = [
  { name: 'Shirts', slug: 'shirts' },
  { name: 'Baggy Jeans', slug: 'baggy-jeans' },
  { name: 'Two Piece Sets', slug: 'two-piece-sets' },
  { name: 'Denim Jackets', slug: 'denim-jackets' },
  { name: 'Varsity Jackets', slug: 'varsity-jackets' },
  { name: 'Tracksuits', slug: 'tracksuits' },
  { name: 'Plain T Shirts', slug: 'plain-t-shirts' },
  { name: 'Polo Shirts', slug: 'polo-shirts' },
  { name: 'Jeans', slug: 'jeans' },
  { name: 'Cargo Pants', slug: 'cargo-pants' },
  { name: 'Shorts', slug: 'shorts' },
  { name: 'Joggers', slug: 'joggers' },
  { name: 'Hoodies', slug: 'hoodies' },
  { name: 'Sweatshirts', slug: 'sweatshirts' },
  { name: 'Bracelets', slug: 'bracelets' },
  { name: 'Jewelries', slug: 'jewelries' },
  { name: 'Branding Luxury Watches', slug: 'branding-luxury-watches' },
  { name: 'Eye Glasses', slug: 'eye-glasses' },
];

async function seedCategories() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  
  try {
    for (const cat of categories) {
      await connection.execute(
        'INSERT INTO categories (name, slug, description, createdAt, updatedAt) VALUES (?, ?, ?, NOW(), NOW())',
        [cat.name, cat.slug, `${cat.name} collection`]
      );
      console.log(`✓ Added category: ${cat.name}`);
    }
    console.log('\n✅ All categories seeded successfully!');
  } catch (error) {
    console.error('Error seeding categories:', error);
  } finally {
    await connection.end();
  }
}

seedCategories();
