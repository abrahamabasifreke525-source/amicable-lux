# Amicable Luxury - Setup & Usage Guide

Welcome to Amicable Luxury, a premium luxury fashion e-commerce boutique website with WhatsApp integration and admin dashboard.

## Overview

This is a full-stack luxury fashion e-commerce platform featuring:

**Public Storefront:**
- Elegant hero section with brand messaging
- Product catalog with category filtering
- Product detail pages with image gallery and size/color selection
- WhatsApp integration for seamless ordering
- About page with brand story
- Mobile-first responsive design

**Admin Dashboard:**
- Owner-only product management (add, edit, delete)
- Category management
- Product status tracking (featured, sold out)
- Role-based access control

## Getting Started

### Prerequisites

- Node.js 22+
- pnpm package manager
- Database connection (MySQL/TiDB)

### Installation

The project is already initialized with all dependencies installed. The development server is running at:
`https://3000-i3w3x83q1cwixeaieb9ce-01a31158.us2.manus.computer`

### Project Structure

```
client/                    # React frontend
├── src/
│   ├── pages/            # Page components
│   │   ├── Home.tsx      # Homepage with hero section
│   │   ├── Shop.tsx      # Product catalog
│   │   ├── ProductDetail.tsx  # Product page
│   │   ├── CategoryPage.tsx   # Category browsing
│   │   ├── About.tsx     # About page
│   │   └── AdminDashboard.tsx # Admin panel
│   ├── components/       # Reusable components
│   └── index.css         # Global styles with luxury palette
server/                    # Express backend
├── routers.ts            # tRPC procedures
├── db.ts                 # Database helpers
└── _core/                # Framework code
drizzle/                  # Database schema & migrations
```

## Key Features

### 1. Public Storefront

**Home Page** (`/`)
- Hero section with brand tagline
- Featured products section
- Collections overview
- Why choose us section
- About preview
- WhatsApp contact button

**Shop Page** (`/shop`)
- Product grid with responsive layout
- Category filtering
- Product cards with price and status
- Mobile-optimized sidebar navigation

**Product Detail** (`/product/:id`)
- Full product information
- Image gallery (placeholder for actual images)
- Size and color selection
- Pre-filled WhatsApp order button
- Product benefits section

**Category Page** (`/category/:slug`)
- Browse products by collection
- Filtered product grid
- Category-specific navigation

**About Page** (`/about`)
- Brand story and values
- Team information
- Why choose us details
- Contact options

### 2. Admin Dashboard

**Access:** `/admin` (admin-only)

**Features:**
- Product management (CRUD operations)
- Add new products with:
  - Name, description, price
  - Category selection
  - Size and color options
  - Featured product toggle
  - Sold out status
- Edit existing products
- Delete products with confirmation dialog
- Product list with status indicators

**Access Control:**
- Only users with `role: "admin"` can access the dashboard
- Non-admin users are redirected to home page
- All backend mutations are protected with role-based checks

### 3. WhatsApp Integration

WhatsApp is integrated throughout the site:

- **Product Detail Page:** Pre-filled order message with product details
- **Footer:** Direct WhatsApp contact link
- **About Page:** WhatsApp contact option
- **Shop Page:** Help/styling advice button

WhatsApp Number: `2348164929650`

## Design System

### Color Palette (Luxury Aesthetic)

- **Primary Background:** White (`oklch(1 0 0)`)
- **Primary Foreground:** Black (`oklch(0 0 0)`)
- **Accent Color:** Gold (`oklch(0.72 0.15 60)`)
- **Muted:** Light gray (`oklch(0.95 0.01 0)`)
- **Border:** Medium gray (`oklch(0.88 0.01 0)`)

### Typography

- **Display Font:** Playfair Display (headings)
- **Body Font:** Lato (body text)
- **Letter Spacing:** Tight for elegance

### Responsive Design

- **Mobile First:** All layouts designed for mobile first
- **Breakpoints:**
  - Mobile: < 768px
  - Tablet: 768px - 1024px
  - Desktop: > 1024px

## Database Schema

### Tables

**categories**
- id (primary key)
- name (string)
- slug (string, unique)
- description (text)
- createdAt (timestamp)
- updatedAt (timestamp)

**products**
- id (primary key)
- name (string)
- description (text)
- price (integer, in cents)
- categoryId (foreign key)
- sizes (JSON array)
- colors (JSON array)
- isFeatured (boolean)
- isSoldOut (boolean)
- createdAt (timestamp)
- updatedAt (timestamp)

**productImages**
- id (primary key)
- productId (foreign key)
- imageUrl (string)
- altText (string)
- displayOrder (integer)
- createdAt (timestamp)

## API Endpoints

All API calls use tRPC. Key procedures:

### Products
- `products.list(categoryId?)` - Get all products, optionally filtered by category
- `products.get(id)` - Get single product
- `products.create(data)` - Create product (admin only)
- `products.update(id, data)` - Update product (admin only)
- `products.delete(id)` - Delete product (admin only)

### Categories
- `categories.list()` - Get all categories

### Auth
- `auth.me()` - Get current user
- `auth.logout()` - Logout current user

## Development

### Running Tests

```bash
pnpm test
```

Tests include:
- Auth logout functionality
- Product CRUD operations
- Admin access control
- Role-based permission checks

### Building for Production

```bash
pnpm build
```

### Environment Variables

Required environment variables (automatically injected):
- `DATABASE_URL` - Database connection string
- `JWT_SECRET` - Session signing secret
- `VITE_APP_ID` - OAuth app ID
- `OAUTH_SERVER_URL` - OAuth server URL
- `VITE_OAUTH_PORTAL_URL` - OAuth portal URL

## Customization

### Adding Products

1. Navigate to `/admin`
2. Click "Add Product"
3. Fill in product details:
   - Name, description, price
   - Select category
   - Enter sizes (comma-separated)
   - Enter colors (comma-separated)
   - Toggle featured/sold out status
4. Click "Add Product"

### Updating Brand Information

Edit the following files to customize:
- **Brand Name:** `client/src/pages/Home.tsx`, `client/src/pages/Shop.tsx`, etc.
- **WhatsApp Number:** `client/src/pages/ProductDetail.tsx`, `client/src/pages/Shop.tsx`, etc.
- **Social Links:** Footer components
- **Colors:** `client/src/index.css` (CSS variables)

### Adding Categories

Categories must be added directly to the database. Contact your database administrator to add new categories to the `categories` table.

## Performance Optimizations

- Smooth scrolling for better UX
- Optimized images with lazy loading
- Responsive grid layouts
- Mobile-first CSS
- Efficient tRPC caching

## SEO

The site includes:
- Meta tags for all pages
- Open Graph tags for social sharing
- Twitter card tags
- Structured data (JSON-LD)
- Canonical URLs
- Mobile-friendly design

## Support

For issues or questions:
- WhatsApp: 2348164929650
- Email: amicablegabriel898@gmail.com
- Instagram: @amicableluxury

## License

All rights reserved. Amicable Luxury 2026.
