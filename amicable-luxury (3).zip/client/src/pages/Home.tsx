import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";
import { Instagram, MessageCircle, Mail, ArrowRight, Settings } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Home() {
  const { user } = useAuth();
  const [featured, setFeatured] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);

  const productsQuery = trpc.products.list.useQuery({ isFeatured: true });
  const categoriesQuery = trpc.categories.list.useQuery();

  useEffect(() => {
    if (productsQuery.data) {
      setFeatured(productsQuery.data);
    }
  }, [productsQuery.data]);

  useEffect(() => {
    if (categoriesQuery.data) {
      setCategories(categoriesQuery.data);
    }
  }, [categoriesQuery.data]);

  const whatsappNumber = "2348164929650";
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=Hello%20Amicable%20Luxury,%20I%20want%20to%20explore%20your%20collection.`;
  const instagramUrl = "https://www.instagram.com/amicableluxury?igsh=cnYxdnEweHNrMWsw";

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/">
            <h1 className="text-2xl font-bold tracking-tight cursor-pointer">Amicable Luxury</h1>
          </Link>
          <div className="flex gap-6 items-center">
            <Link href="/shop">
              <span className="text-sm font-medium hover:text-accent transition-colors cursor-pointer">
                Shop
              </span>
            </Link>
            <Link href="/about">
              <span className="text-sm font-medium hover:text-accent transition-colors cursor-pointer">
                About
              </span>
            </Link>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm font-medium hover:text-accent transition-colors"
            >
              Contact
            </a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative w-full min-h-[90vh] flex items-center justify-center bg-gradient-to-b from-background via-background to-muted overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-10 right-10 w-72 h-72 bg-accent rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 left-10 w-96 h-96 bg-accent rounded-full blur-3xl"></div>
        </div>

        <div className="relative z-10 container mx-auto px-4 py-20 text-center max-w-3xl">
          <div className="mb-6">
            <span className="text-accent text-sm font-semibold tracking-widest uppercase">
              Premium Fashion Collection
            </span>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold mb-6 tracking-tight leading-tight">
            Luxury Fashion Designed For Confidence
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed">
            Premium fashion pieces crafted for elegance, confidence, and timeless style. Discover our exclusive collection of luxury wears.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link href="/shop">
              <Button size="lg" className="bg-foreground text-background hover:bg-foreground/90 w-full sm:w-auto">
                Shop Collection
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
              <Button
                size="lg"
                variant="outline"
                className="w-full sm:w-auto border-foreground text-foreground hover:bg-foreground/5"
              >
                <MessageCircle className="mr-2 h-4 w-4" />
                Contact on WhatsApp
              </Button>
            </a>
          </div>

          {/* Featured Stats */}
          <div className="grid grid-cols-3 gap-4 text-center text-sm">
            <div>
              <div className="text-2xl font-bold text-accent">100%</div>
              <div className="text-muted-foreground">Premium Quality</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-accent">Fast</div>
              <div className="text-muted-foreground">Delivery</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-accent">24/7</div>
              <div className="text-muted-foreground">Support</div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      {featured.length > 0 && (
        <section className="py-20 bg-background">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold mb-4">Featured Collection</h2>
              <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
                Handpicked luxury pieces that define elegance and sophistication
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featured.slice(0, 6).map((product) => (
                  <Link key={product.id} href={`/product/${product.id}`}>
                    <Card className="group cursor-pointer overflow-hidden border-border hover:shadow-lg transition-all duration-300 h-full flex flex-col">
                      <div className="aspect-square bg-muted overflow-hidden">
                        {product.firstImage ? (
                          <img
                            src={product.firstImage.imageUrl}
                            alt={product.firstImage.altText || product.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        ) : (
                          <div className="w-full h-full bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center group-hover:from-muted/80 group-hover:to-muted/40 transition-colors">
                            <span className="text-muted-foreground">No Image</span>
                          </div>
                        )}
                      </div>
                    <div className="p-6">
                      <h3 className="text-lg font-semibold mb-2 group-hover:text-accent transition-colors">
                        {product.name}
                      </h3>
                      <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                        {product.description || "Premium luxury wear"}
                      </p>
                      <div className="flex justify-between items-center">
                        <span className="text-xl font-bold text-accent">
                          ₦{(product.price / 100).toLocaleString()}
                        </span>
                        {product.isSoldOut ? (
                          <span className="text-sm font-semibold text-destructive">Sold Out</span>
                        ) : (
                          <ArrowRight className="h-4 w-4 text-accent group-hover:translate-x-1 transition-transform" />
                        )}
                      </div>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>

            <div className="text-center mt-12">
              <Link href="/shop">
                <Button size="lg" variant="outline" className="border-foreground">
                  View All Products
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* Categories */}
      {categories.length > 0 && (
        <section className="py-20 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold mb-4">Collections</h2>
              <p className="text-muted-foreground text-lg">
                Explore our curated collections
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {categories.map((category) => (
                <Link key={category.id} href={`/category/${category.slug}`}>
                  <Card className="group cursor-pointer overflow-hidden border-border hover:shadow-lg transition-all duration-300 h-48">
                    <div className="w-full h-full bg-gradient-to-br from-accent/20 to-accent/5 flex flex-col items-center justify-center p-6 text-center hover:from-accent/30 hover:to-accent/10 transition-colors">
                      <h3 className="text-2xl font-bold group-hover:text-accent transition-colors">
                        {category.name}
                      </h3>
                      {category.description && (
                        <p className="text-sm text-muted-foreground mt-2">
                          {category.description}
                        </p>
                      )}
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Why Choose Us */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Why Choose Amicable Luxury</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { title: "Premium Quality", description: "Handpicked luxury pieces with impeccable craftsmanship" },
              { title: "Fast Delivery", description: "Quick and reliable delivery to your doorstep" },
              { title: "Trusted Brand", description: "Established luxury brand with loyal customers" },
              { title: "Luxury Packaging", description: "Premium packaging for an unforgettable experience" },
            ].map((item, idx) => (
              <div key={idx} className="text-center">
                <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <div className="w-8 h-8 bg-accent rounded-full"></div>
                </div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">About Amicable Luxury</h2>
          </div>

          <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
            <p>
              Amicable Luxury is a premium fashion boutique dedicated to bringing elegance and confidence to every customer. We believe that luxury fashion should be accessible, authentic, and empowering.
            </p>
            <p>
              Our carefully curated collection features premium wears designed for the modern individual who values quality, style, and sophistication. Each piece is selected to ensure it meets our rigorous standards of excellence.
            </p>
            <p>
              We are committed to providing an exceptional customer experience, from browsing our collection to receiving your order. Our dedicated team is always ready to assist you with any inquiries or special requests.
            </p>
          </div>
        </div>
      </section>

      {/* Instagram Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Follow Us</h2>
          <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto">
            Stay updated with our latest collections and fashion inspiration on Instagram
          </p>

          <a href={instagramUrl} target="_blank" rel="noopener noreferrer">
            <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
              <Instagram className="mr-2 h-5 w-5" />
              Follow on Instagram
            </Button>
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background py-12 border-t border-border">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-lg mb-4">Amicable Luxury</h3>
              <p className="text-background/80 text-sm">
                Premium fashion for the modern individual
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Navigation</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/shop">
                    <span className="text-background/80 hover:text-background transition-colors cursor-pointer">
                      Shop
                    </span>
                  </Link>
                </li>
                <li>
                  <Link href="/about">
                    <span className="text-background/80 hover:text-background transition-colors cursor-pointer">
                      About
                    </span>
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a
                    href={`https://wa.me/${whatsappNumber}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-background/80 hover:text-background transition-colors flex items-center gap-2"
                  >
                    <MessageCircle className="h-4 w-4" />
                    WhatsApp
                  </a>
                </li>
                <li>
                  <a
                    href="mailto:amicablegabriel898@gmail.com"
                    className="text-background/80 hover:text-background transition-colors flex items-center gap-2"
                  >
                    <Mail className="h-4 w-4" />
                    Email
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Follow</h4>
              <div className="space-y-2">
                <a
                  href={instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-background/80 hover:text-background transition-colors flex items-center gap-2"
                >
                  <Instagram className="h-4 w-4" />
                  Instagram
                </a>
                {user?.role === "admin" && (
                  <Link href="/admin">
                    <span className="text-background/80 hover:text-background transition-colors flex items-center gap-2 cursor-pointer">
                      <Settings className="h-4 w-4" />
                      Admin Dashboard
                    </span>
                  </Link>
                )}
              </div>
            </div>
          </div>

          <div className="border-t border-background/20 pt-8 text-center text-sm text-background/60">
            <p>&copy; 2026 Amicable Luxury. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
