import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MessageCircle, Instagram, Mail, ArrowRight } from "lucide-react";

export default function About() {
  const whatsappNumber = "2348164929650";
  const instagramUrl = "https://www.instagram.com/amicableluxury?igsh=cnYxdnEweHNrMWsw";

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/">
            <h1 className="text-2xl font-bold tracking-tight cursor-pointer">Amicable Luxury</h1>
          </Link>
          <div className="flex gap-6 items-center">
            <Link href="/shop">
              <span className="text-sm font-medium hover:text-accent transition-colors cursor-pointer">
                Shop
              </span>
            </Link>
            <Link href="/about">
              <span className="text-sm font-medium text-accent cursor-pointer">About</span>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 bg-muted/30 border-b border-border">
        <div className="container mx-auto px-4 max-w-3xl text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">About Amicable Luxury</h1>
          <p className="text-xl text-muted-foreground leading-relaxed">
            We believe luxury fashion should be accessible, authentic, and empowering. Our mission is to bring elegance and confidence to every customer through carefully curated premium pieces.
          </p>
        </div>
      </section>

      {/* Brand Story */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="space-y-8">
            <div>
              <h2 className="text-4xl font-bold mb-6">Our Story</h2>
              <p className="text-lg text-muted-foreground leading-relaxed mb-4">
                Amicable Luxury was founded with a simple vision: to make premium fashion accessible to everyone who values quality, style, and sophistication. We understand that true luxury is not just about the price tag—it's about the craftsmanship, the attention to detail, and the confidence that comes from wearing something truly special.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed mb-4">
                Every piece in our collection is carefully selected to meet our rigorous standards of excellence. We work directly with trusted suppliers and artisans to ensure that each item reflects our commitment to quality and elegance. From the finest fabrics to the most meticulous stitching, we believe that luxury should be evident in every detail.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                What sets us apart is our dedication to customer experience. We don't just sell products—we build relationships. Our team is always ready to help you find the perfect piece, answer your questions, and ensure that your shopping experience with us is nothing short of exceptional.
              </p>
            </div>

            {/* Values */}
            <div>
              <h2 className="text-4xl font-bold mb-8">Our Values</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[
                  {
                    title: "Elegance",
                    description: "We believe that true elegance is timeless. Every piece in our collection is designed to transcend trends and remain beautiful for years to come.",
                  },
                  {
                    title: "Confidence",
                    description: "Fashion should make you feel confident. We curate pieces that empower our customers to express themselves and embrace their unique style.",
                  },
                  {
                    title: "Premium Quality",
                    description: "We never compromise on quality. Each item is handpicked to ensure it meets our exacting standards for materials, craftsmanship, and design.",
                  },
                  {
                    title: "Luxury Experience",
                    description: "From browsing to delivery, we ensure every interaction with Amicable Luxury reflects our commitment to excellence and customer satisfaction.",
                  },
                ].map((value, idx) => (
                  <Card key={idx} className="p-6 border-border bg-muted/30">
                    <h3 className="text-xl font-bold mb-3 text-accent">{value.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{value.description}</p>
                  </Card>
                ))}
              </div>
            </div>

            {/* Why Choose Us */}
            <div>
              <h2 className="text-4xl font-bold mb-8">Why Choose Amicable Luxury</h2>
              <div className="space-y-4">
                {[
                  {
                    title: "Curated Selection",
                    description: "Every item is handpicked by our team of fashion experts to ensure quality and style.",
                  },
                  {
                    title: "Authentic Products",
                    description: "We guarantee the authenticity and quality of every piece we offer.",
                  },
                  {
                    title: "Exceptional Service",
                    description: "Our dedicated team is available to assist you with any questions or special requests.",
                  },
                  {
                    title: "Fast & Reliable Delivery",
                    description: "We ensure your order reaches you quickly and safely, with premium packaging.",
                  },
                  {
                    title: "Customer-Centric Approach",
                    description: "Your satisfaction is our priority. We're committed to making your experience exceptional.",
                  },
                  {
                    title: "Luxury Packaging",
                    description: "Every order is packaged with care, making unboxing an unforgettable experience.",
                  },
                ].map((item, idx) => (
                  <div key={idx} className="flex gap-4">
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center mt-1">
                      <div className="w-2 h-2 rounded-full bg-accent"></div>
                    </div>
                    <div>
                      <h3 className="font-semibold mb-1">{item.title}</h3>
                      <p className="text-muted-foreground text-sm">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-muted/30 border-y border-border">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Meet Our Team</h2>
            <p className="text-lg text-muted-foreground">
              Passionate fashion enthusiasts dedicated to bringing you the best luxury experience
            </p>
          </div>

          <Card className="p-8 border-border bg-background text-center">
            <h3 className="text-2xl font-bold mb-2">Gabriel</h3>
            <p className="text-accent font-semibold mb-4">Founder & Fashion Curator</p>
            <p className="text-muted-foreground leading-relaxed">
              With a passion for luxury fashion and a keen eye for quality, Gabriel founded Amicable Luxury to share his love of premium pieces with the world. Every item in our collection reflects his commitment to excellence and his belief that luxury should be accessible to everyone.
            </p>
          </Card>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4 max-w-3xl text-center">
          <h2 className="text-4xl font-bold mb-6">Get in Touch</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Have questions or want to learn more about our collection? We'd love to hear from you!
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href={`https://wa.me/${whatsappNumber}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 w-full sm:w-auto">
                <MessageCircle className="mr-2 h-5 w-5" />
                Chat on WhatsApp
              </Button>
            </a>
            <a href={instagramUrl} target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="border-foreground w-full sm:w-auto">
                <Instagram className="mr-2 h-5 w-5" />
                Follow on Instagram
              </Button>
            </a>
            <a href="mailto:amicablegabriel898@gmail.com">
              <Button size="lg" variant="outline" className="border-foreground w-full sm:w-auto">
                <Mail className="mr-2 h-5 w-5" />
                Email Us
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* CTA to Shop */}
      <section className="py-16 bg-muted/30 border-t border-border">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Explore?</h2>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Browse our curated collection of premium luxury pieces
          </p>
          <Link href="/shop">
            <Button size="lg" className="bg-foreground text-background hover:bg-foreground/90">
              Shop Now
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background py-12 border-t border-border">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-lg mb-4">Amicable Luxury</h3>
              <p className="text-background/80 text-sm">Premium fashion for the modern individual</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Navigation</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/">
                    <span className="text-background/80 hover:text-background transition-colors cursor-pointer">
                      Home
                    </span>
                  </Link>
                </li>
                <li>
                  <Link href="/shop">
                    <span className="text-background/80 hover:text-background transition-colors cursor-pointer">
                      Shop
                    </span>
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a
                    href={`https://wa.me/${whatsappNumber}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-background/80 hover:text-background transition-colors"
                  >
                    WhatsApp
                  </a>
                </li>
                <li>
                  <a
                    href="mailto:amicablegabriel898@gmail.com"
                    className="text-background/80 hover:text-background transition-colors"
                  >
                    Email
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Follow</h4>
              <a
                href={instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-background/80 hover:text-background transition-colors"
              >
                Instagram
              </a>
            </div>
          </div>
          <div className="border-t border-background/20 pt-8 text-center text-sm text-background/60">
            <p>&copy; 2026 Amicable Luxury. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
