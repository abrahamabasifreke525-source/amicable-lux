import { useState, useEffect } from "react";
import { useRoute, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, MessageCircle, ArrowLeft } from "lucide-react";

export default function CategoryPage() {
  const [match, params] = useRoute("/category/:slug");
  const [products, setProducts] = useState<any[]>([]);
  const [category, setCategory] = useState<any>(null);

  const categoriesQuery = trpc.categories.list.useQuery();
  const productsQuery = trpc.products.list.useQuery(
    { categoryId: category?.id },
    { enabled: !!category }
  );

  useEffect(() => {
    if (categoriesQuery.data && params?.slug) {
      const found = categoriesQuery.data.find((c) => c.slug === params.slug);
      setCategory(found);
    }
  }, [categoriesQuery.data, params?.slug]);

  useEffect(() => {
    if (productsQuery.data) {
      setProducts(productsQuery.data);
    }
  }, [productsQuery.data]);

  if (!match) return null;

  if (!category && !categoriesQuery.isLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <nav className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
          <div className="container mx-auto px-4 py-4">
            <Link href="/shop">
              <Button variant="ghost" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Back to Shop
              </Button>
            </Link>
          </div>
        </nav>
        <div className="container mx-auto px-4 py-12 text-center">
          <h1 className="text-2xl font-bold mb-4">Collection not found</h1>
          <Link href="/shop">
            <Button>Return to Shop</Button>
          </Link>
        </div>
      </div>
    );
  }

  const whatsappNumber = "2348164929650";

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/">
            <h1 className="text-2xl font-bold tracking-tight cursor-pointer">Amicable Luxury</h1>
          </Link>
          <div className="flex gap-6 items-center">
            <Link href="/shop">
              <span className="text-sm font-medium hover:text-accent transition-colors cursor-pointer">
                Shop
              </span>
            </Link>
            <Link href="/about">
              <span className="text-sm font-medium hover:text-accent transition-colors cursor-pointer">
                About
              </span>
            </Link>
          </div>
        </div>
      </nav>

      {/* Header */}
      <section className="py-12 bg-muted/30 border-b border-border">
        <div className="container mx-auto px-4">
          <Link href="/shop">
            <Button variant="ghost" className="gap-2 mb-4">
              <ArrowLeft className="h-4 w-4" />
              Back to Shop
            </Button>
          </Link>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">{category?.name || "Collection"}</h1>
          {category?.description && (
            <p className="text-muted-foreground text-lg">{category.description}</p>
          )}
        </div>
      </section>

      {/* Products Grid */}
      <div className="container mx-auto px-4 py-12">
        {productsQuery.isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[...Array(8)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <div className="aspect-square bg-muted"></div>
                <div className="p-6 space-y-4">
                  <div className="h-4 bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded w-2/3"></div>
                </div>
              </Card>
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg mb-6">
              No products in this collection yet
            </p>
            <Link href="/shop">
              <Button>Browse All Products</Button>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {products.map((product) => (
              <Link key={product.id} href={`/product/${product.id}`}>
                <Card className="group cursor-pointer overflow-hidden border-border hover:shadow-lg transition-all duration-300 h-full flex flex-col">
                  <div className="aspect-square bg-muted overflow-hidden">
                    {product.firstImage ? (
                      <img
                        src={product.firstImage.imageUrl}
                        alt={product.firstImage.altText || product.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center group-hover:from-muted/80 group-hover:to-muted/40 transition-colors">
                        <span className="text-muted-foreground">No Image</span>
                      </div>
                    )}
                  </div>
                  <div className="p-6 flex flex-col flex-grow">
                    <h3 className="text-lg font-semibold mb-2 group-hover:text-accent transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-muted-foreground text-sm mb-4 line-clamp-2 flex-grow">
                      {product.description || "Premium luxury wear"}
                    </p>
                    <div className="flex justify-between items-center">
                      <span className="text-xl font-bold text-accent">
                        ₦{(product.price / 100).toLocaleString()}
                      </span>
                      {product.isSoldOut ? (
                        <span className="text-sm font-semibold text-destructive">Sold Out</span>
                      ) : (
                        <ArrowRight className="h-4 w-4 text-accent group-hover:translate-x-1 transition-transform" />
                      )}
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>

      {/* CTA Section */}
      {products.length > 0 && (
        <section className="py-16 bg-muted/30 border-t border-border">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Need Help Choosing?</h2>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Contact us on WhatsApp for personalized styling advice and product recommendations
            </p>
            <a
              href={`https://wa.me/${whatsappNumber}?text=Hello%20Amicable%20Luxury,%20I%20need%20help%20with%20choosing%20a%20product.`}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
                <MessageCircle className="mr-2 h-5 w-5" />
                Chat on WhatsApp
              </Button>
            </a>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="bg-foreground text-background py-12 border-t border-border">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-lg mb-4">Amicable Luxury</h3>
              <p className="text-background/80 text-sm">Premium fashion for the modern individual</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Navigation</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/">
                    <span className="text-background/80 hover:text-background transition-colors cursor-pointer">
                      Home
                    </span>
                  </Link>
                </li>
                <li>
                  <Link href="/shop">
                    <span className="text-background/80 hover:text-background transition-colors cursor-pointer">
                      Shop
                    </span>
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a
                    href={`https://wa.me/${whatsappNumber}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-background/80 hover:text-background transition-colors"
                  >
                    WhatsApp
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Follow</h4>
              <a
                href="https://www.instagram.com/amicableluxury?igsh=cnYxdnEweHNrMWsw"
                target="_blank"
                rel="noopener noreferrer"
                className="text-background/80 hover:text-background transition-colors"
              >
                Instagram
              </a>
            </div>
          </div>
          <div className="border-t border-background/20 pt-8 text-center text-sm text-background/60">
            <p>&copy; 2026 Amicable Luxury. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
