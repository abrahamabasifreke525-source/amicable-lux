import { useState, useEffect } from "react";
import { useRoute, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MessageCircle, ArrowLeft, Check } from "lucide-react";

export default function ProductDetail() {
  const [match, params] = useRoute("/product/:id");
  const [product, setProduct] = useState<any>(null);
  const [selectedSize, setSelectedSize] = useState<string>("");
  const [selectedColor, setSelectedColor] = useState<string>("");
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const productQuery = trpc.products.get.useQuery(
    { id: parseInt(params?.id || "0") },
    { enabled: !!params?.id }
  );

  useEffect(() => {
    if (productQuery.data) {
      const productData = productQuery.data;
      setProduct(productData);

      // Parse sizes and colors from JSON strings
      if (productData.sizes) {
        const sizes = JSON.parse(productData.sizes);
        setSelectedSize(sizes[0] || "");
      }
      if (productData.colors) {
        const colors = JSON.parse(productData.colors);
        setSelectedColor(colors[0] || "");
      }
    }
  }, [productQuery.data]);

  if (!match) return null;

  if (productQuery.isLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading product...</p>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <nav className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
          <div className="container mx-auto px-4 py-4">
            <Link href="/shop">
              <Button variant="ghost" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Back to Shop
              </Button>
            </Link>
          </div>
        </nav>
        <div className="container mx-auto px-4 py-12 text-center">
          <h1 className="text-2xl font-bold mb-4">Product not found</h1>
          <Link href="/shop">
            <Button>Return to Shop</Button>
          </Link>
        </div>
      </div>
    );
  }

  const sizes = JSON.parse(product.sizes || "[]");
  const colors = JSON.parse(product.colors || "[]");
  const images = product.images || [];
  const whatsappNumber = "2348164929650";
  const whatsappMessage = `Hello Amicable Luxury, I want to order ${product.name}. Size: ${selectedSize}, Color: ${selectedColor}. Price: ₦${(product.price / 100).toLocaleString()}`;
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(whatsappMessage)}`;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/">
            <h1 className="text-2xl font-bold tracking-tight cursor-pointer">Amicable Luxury</h1>
          </Link>
          <Link href="/shop">
            <Button variant="ghost" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Shop
            </Button>
          </Link>
        </div>
      </nav>

      {/* Product Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Image Gallery */}
          <div className="space-y-4">
            <div className="aspect-square bg-muted rounded-lg overflow-hidden flex items-center justify-center">
              {images.length > 0 ? (
                <img
                  src={images[currentImageIndex]?.imageUrl}
                  alt={images[currentImageIndex]?.altText || product.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="text-muted-foreground text-center">
                  <p>No images available</p>
                  <p className="text-sm mt-2">Product images will be displayed here</p>
                </div>
              )}
            </div>

            {/* Thumbnail Gallery */}
            {images.length > 1 && (
              <div className="grid grid-cols-4 gap-4">
                {images.map((image: any, idx: number) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentImageIndex(idx)}
                    className={`aspect-square rounded-lg overflow-hidden border-2 transition-colors ${
                      currentImageIndex === idx ? "border-accent" : "border-border"
                    }`}
                  >
                    <img
                      src={image.imageUrl}
                      alt={image.altText || `Product ${idx + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Details */}
          <div className="flex flex-col space-y-6">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-2">{product.name}</h1>
              <div className="flex items-center gap-4 mb-4">
                <span className="text-3xl font-bold text-accent">
                  ₦{(product.price / 100).toLocaleString()}
                </span>
                {product.isSoldOut && (
                  <span className="px-4 py-2 bg-destructive/10 text-destructive rounded-full text-sm font-semibold">
                    Sold Out
                  </span>
                )}
              </div>
            </div>

            {product.description && (
              <div>
                <h3 className="text-lg font-semibold mb-2">Description</h3>
                <p className="text-muted-foreground leading-relaxed">{product.description}</p>
              </div>
            )}

            {/* Size Selection */}
            {sizes.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mb-4">Size</h3>
                <div className="grid grid-cols-4 gap-3">
                  {sizes.map((size: string) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      disabled={product.isSoldOut}
                      className={`py-3 px-4 rounded-lg border-2 font-semibold transition-all ${
                        selectedSize === size
                          ? "border-accent bg-accent/10 text-accent"
                          : "border-border text-foreground hover:border-accent"
                      } ${product.isSoldOut ? "opacity-50 cursor-not-allowed" : ""}`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Color Selection */}
            {colors.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mb-4">Color</h3>
                <div className="grid grid-cols-4 gap-3">
                  {colors.map((color: string) => {
                    const colorMap: Record<string, string> = {
                      'Black': '#000000',
                      'White': '#FFFFFF',
                      'Red': '#EF4444',
                      'Blue': '#3B82F6',
                      'Green': '#10B981',
                      'Yellow': '#FBBF24',
                      'Purple': '#A855F7',
                      'Pink': '#EC4899',
                      'Orange': '#F97316',
                      'Brown': '#92400E',
                      'Gray': '#6B7280',
                      'Navy': '#001F3F',
                      'Teal': '#14B8A6',
                      'Gold': '#D97706',
                      'Silver': '#C0C0C0',
                      'Beige': '#F5E6D3',
                      'Cream': '#FFFDD0',
                      'Khaki': '#F0E68C',
                    };
                    const hexColor = colorMap[color] || '#CCCCCC';
                    return (
                      <button
                        key={color}
                        onClick={() => setSelectedColor(color)}
                        disabled={product.isSoldOut}
                        className={`relative py-3 px-4 rounded-lg border-2 font-semibold transition-all flex items-center gap-2 ${
                          selectedColor === color
                            ? "border-accent ring-2 ring-accent"
                            : "border-border hover:border-accent"
                        } ${product.isSoldOut ? "opacity-50 cursor-not-allowed" : ""}`}
                      >
                        <div
                          className="w-5 h-5 rounded-full border border-foreground/20"
                          style={{ backgroundColor: hexColor }}
                        />
                        <span className="text-sm">{color}</span>
                        {selectedColor === color && (
                          <Check className="h-4 w-4 ml-auto text-accent" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Order Button */}
            <div className="space-y-3 pt-6">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="block"
              >
                <Button
                  size="lg"
                  className="w-full bg-accent text-accent-foreground hover:bg-accent/90"
                  disabled={product.isSoldOut}
                >
                  <MessageCircle className="mr-2 h-5 w-5" />
                  Order on WhatsApp
                </Button>
              </a>

              {product.isSoldOut && (
                <p className="text-center text-sm text-destructive font-semibold">
                  This item is currently sold out. Please contact us for availability.
                </p>
              )}
            </div>

            {/* Product Info */}
            <Card className="p-6 bg-muted/30 border-border">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Check className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Premium Quality</h4>
                    <p className="text-sm text-muted-foreground">
                      Handpicked luxury pieces with impeccable craftsmanship
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Check className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Fast Delivery</h4>
                    <p className="text-sm text-muted-foreground">
                      Quick and reliable delivery to your doorstep
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Check className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Luxury Packaging</h4>
                    <p className="text-sm text-muted-foreground">
                      Premium packaging for an unforgettable experience
                    </p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-foreground text-background py-12 border-t border-border mt-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-lg mb-4">Amicable Luxury</h3>
              <p className="text-background/80 text-sm">Premium fashion for the modern individual</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Navigation</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/">
                    <span className="text-background/80 hover:text-background transition-colors cursor-pointer">
                      Home
                    </span>
                  </Link>
                </li>
                <li>
                  <Link href="/shop">
                    <span className="text-background/80 hover:text-background transition-colors cursor-pointer">
                      Shop
                    </span>
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a
                    href={`https://wa.me/${whatsappNumber}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-background/80 hover:text-background transition-colors"
                  >
                    WhatsApp
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Follow</h4>
              <a
                href="https://www.instagram.com/amicableluxury?igsh=cnYxdnEweHNrMWsw"
                target="_blank"
                rel="noopener noreferrer"
                className="text-background/80 hover:text-background transition-colors"
              >
                Instagram
              </a>
            </div>
          </div>
          <div className="border-t border-background/20 pt-8 text-center text-sm text-background/60">
            <p>&copy; 2026 Amicable Luxury. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
