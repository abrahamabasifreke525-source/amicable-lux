import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Upload, X } from "lucide-react";
import { trpc } from "@/lib/trpc";

interface ImageUploadDialogProps {
  productId: number;
  productName: string;
  onUploadSuccess?: () => void;
}

export function ImageUploadDialog({
  productId,
  productName,
  onUploadSuccess,
}: ImageUploadDialogProps) {
  const [open, setOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>("");
  const [altText, setAltText] = useState("");
  const [displayOrder, setDisplayOrder] = useState("0");

  const uploadImageMutation = trpc.images.upload.useMutation();

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith("image/")) {
      toast.error("Please select an image file");
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image size must be less than 5MB");
      return;
    }

    setSelectedFile(file);

    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      toast.error("Please select an image");
      return;
    }

    try {
      // Read file as base64
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64Data = (e.target?.result as string).split(",")[1];
        if (!base64Data) {
          toast.error("Failed to read file");
          return;
        }

        try {
          await uploadImageMutation.mutateAsync({
            productId,
            fileName: selectedFile.name,
            fileData: base64Data,
            mimeType: selectedFile.type,
            altText: altText || selectedFile.name,
            displayOrder: parseInt(displayOrder),
          });

          toast.success("Image uploaded successfully");
          setOpen(false);
          resetForm();
          onUploadSuccess?.();
        } catch (error) {
          toast.error("Failed to upload image");
        }
      };
      reader.readAsDataURL(selectedFile);
    } catch (error) {
      toast.error("Failed to process image");
    }
  };

  const resetForm = () => {
    setSelectedFile(null);
    setPreview("");
    setAltText("");
    setDisplayOrder("0");
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          size="sm"
          variant="outline"
          className="gap-2"
        >
          <Upload className="h-4 w-4" />
          Upload Image
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Upload Product Image</DialogTitle>
          <p className="text-sm text-muted-foreground mt-1">
            Uploading for: <span className="font-semibold">{productName}</span>
          </p>
        </DialogHeader>

        <div className="space-y-4">
          {/* File Input */}
          <div>
            <label className="text-sm font-semibold mb-2 block">Select Image *</label>
            <div className="relative">
              <input
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
                id="image-input"
              />
              <label
                htmlFor="image-input"
                className="flex items-center justify-center w-full px-4 py-8 border-2 border-dashed border-border rounded-lg cursor-pointer hover:bg-muted/50 transition"
              >
                {preview ? (
                  <div className="text-center">
                    <img
                      src={preview}
                      alt="Preview"
                      className="max-h-32 mx-auto mb-2 rounded"
                    />
                    <p className="text-xs text-muted-foreground">{selectedFile?.name}</p>
                  </div>
                ) : (
                  <div className="text-center">
                    <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm font-medium">Click to upload image</p>
                    <p className="text-xs text-muted-foreground">PNG, JPG, GIF up to 5MB</p>
                  </div>
                )}
              </label>
            </div>
          </div>

          {/* Alt Text */}
          <div>
            <label className="text-sm font-semibold mb-2 block">Alt Text</label>
            <Input
              value={altText}
              onChange={(e) => setAltText(e.target.value)}
              placeholder="Describe the image for accessibility"
            />
          </div>

          {/* Display Order */}
          <div>
            <label className="text-sm font-semibold mb-2 block">Display Order</label>
            <Input
              type="number"
              value={displayOrder}
              onChange={(e) => setDisplayOrder(e.target.value)}
              placeholder="0"
              min="0"
            />
            <p className="text-xs text-muted-foreground mt-1">
              Lower numbers appear first (0 = first image)
            </p>
          </div>

          {/* Actions */}
          <div className="flex gap-3 justify-end pt-4">
            <Button
              variant="outline"
              onClick={() => {
                setOpen(false);
                resetForm();
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleUpload}
              className="bg-accent text-accent-foreground hover:bg-accent/90"
              disabled={!selectedFile || uploadImageMutation.isPending}
            >
              {uploadImageMutation.isPending ? "Uploading..." : "Upload Image"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
