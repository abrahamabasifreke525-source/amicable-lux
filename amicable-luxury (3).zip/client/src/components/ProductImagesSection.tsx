import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ImageUploadDialog } from "@/components/ImageUploadDialog";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { toast } from "sonner";
import { Trash2, Image as ImageIcon } from "lucide-react";

interface ProductImagesSectionProps {
  productId: number;
  productName: string;
  onImagesUpdated?: () => void;
}

export function ProductImagesSection({
  productId,
  productName,
  onImagesUpdated,
}: ProductImagesSectionProps) {
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [imageToDelete, setImageToDelete] = useState<number | null>(null);

  const imagesQuery = trpc.products.get.useQuery({ id: productId });
  const deleteImageMutation = trpc.images.delete.useMutation();

  const images = imagesQuery.data?.images || [];

  const handleDeleteImage = async () => {
    if (!imageToDelete) return;

    try {
      await deleteImageMutation.mutateAsync({ id: imageToDelete });
      toast.success("Image deleted successfully");
      setDeleteConfirmOpen(false);
      setImageToDelete(null);
      imagesQuery.refetch();
      onImagesUpdated?.();
    } catch (error) {
      toast.error("Failed to delete image");
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="font-semibold text-lg">Product Images</h3>
          <p className="text-sm text-muted-foreground">
            {images.length} image{images.length !== 1 ? "s" : ""} uploaded
          </p>
        </div>
        <ImageUploadDialog
          productId={productId}
          productName={productName}
          onUploadSuccess={() => {
            imagesQuery.refetch();
            onImagesUpdated?.();
          }}
        />
      </div>

      {images.length === 0 ? (
        <Card className="border-dashed p-8 text-center">
          <ImageIcon className="h-12 w-12 mx-auto text-muted-foreground mb-3 opacity-50" />
          <p className="text-muted-foreground mb-4">No images uploaded yet</p>
          <ImageUploadDialog
            productId={productId}
            productName={productName}
            onUploadSuccess={() => {
              imagesQuery.refetch();
              onImagesUpdated?.();
            }}
          />
        </Card>
      ) : (
        <div className="grid grid-cols-2 gap-4">
          {images.map((image: any) => (
            <Card key={image.id} className="overflow-hidden">
              <div className="aspect-square bg-muted flex items-center justify-center overflow-hidden">
                <img
                  src={image.imageUrl}
                  alt={image.altText || "Product image"}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-3 space-y-2">
                <p className="text-xs text-muted-foreground truncate">
                  {image.altText || "No description"}
                </p>
                <p className="text-xs text-muted-foreground">
                  Order: {image.displayOrder}
                </p>
                <Button
                  size="sm"
                  variant="ghost"
                  className="w-full text-destructive hover:text-destructive"
                  onClick={() => {
                    setImageToDelete(image.id);
                    setDeleteConfirmOpen(true);
                  }}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <ConfirmDialog
        open={deleteConfirmOpen}
        title="Delete Image"
        description="Are you sure you want to delete this image? This action cannot be undone."
        actionLabel="Delete"
        cancelLabel="Cancel"
        onConfirm={handleDeleteImage}
        onCancel={() => {
          setDeleteConfirmOpen(false);
          setImageToDelete(null);
        }}
        isLoading={deleteImageMutation.isPending}
        isDangerous
      />
    </div>
  );
}
