import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import {
  getProducts,
  getProductWithImages,
  createProduct,
  updateProduct,
  deleteProduct,
  getCategories,
  createCategory,
  updateCategory,
  deleteCategory,
  addProductImage,
  deleteProductImage,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  products: router({
    // Public procedures
    list: publicProcedure
      .input(
        z.object({
          categoryId: z.number().optional(),
          isFeatured: z.boolean().optional(),
        })
      )
      .query(async ({ input }) => {
        const products = await getProducts({
          categoryId: input.categoryId,
          isFeatured: input.isFeatured,
          isSoldOut: false,
        });
        return products;
      }),

    get: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getProductWithImages(input.id);
      }),

    // Admin procedures
    create: protectedProcedure
      .use(async ({ ctx, next }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return next({ ctx });
      })
      .input(
        z.object({
          categoryId: z.number(),
          name: z.string().min(1),
          description: z.string().optional(),
          price: z.number().positive(),
          sizes: z.array(z.string()),
          colors: z.array(z.string()),
          isFeatured: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const product = await createProduct({
          categoryId: input.categoryId,
          name: input.name,
          description: input.description,
          price: Math.round(input.price * 100), // Convert to cents
          sizes: JSON.stringify(input.sizes),
          colors: JSON.stringify(input.colors),
          isFeatured: input.isFeatured ? 1 : 0,
          isSoldOut: 0,
        });
        return product;
      }),

    update: protectedProcedure
      .use(async ({ ctx, next }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return next({ ctx });
      })
      .input(
        z.object({
          id: z.number(),
          categoryId: z.number().optional(),
          name: z.string().optional(),
          description: z.string().optional(),
          price: z.number().positive().optional(),
          sizes: z.array(z.string()).optional(),
          colors: z.array(z.string()).optional(),
          isFeatured: z.boolean().optional(),
          isSoldOut: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        const updateData: any = {};

        if (data.categoryId !== undefined) updateData.categoryId = data.categoryId;
        if (data.name !== undefined) updateData.name = data.name;
        if (data.description !== undefined) updateData.description = data.description;
        if (data.price !== undefined) updateData.price = Math.round(data.price * 100);
        if (data.sizes !== undefined) updateData.sizes = JSON.stringify(data.sizes);
        if (data.colors !== undefined) updateData.colors = JSON.stringify(data.colors);
        if (data.isFeatured !== undefined) updateData.isFeatured = data.isFeatured ? 1 : 0;
        if (data.isSoldOut !== undefined) updateData.isSoldOut = data.isSoldOut ? 1 : 0;

        await updateProduct(id, updateData);
      }),

    delete: protectedProcedure
      .use(async ({ ctx, next }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return next({ ctx });
      })
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteProduct(input.id);
      }),
  }),

  categories: router({
    // Public procedures
    list: publicProcedure.query(async () => {
      return getCategories();
    }),

    // Admin procedures
    create: protectedProcedure
      .use(async ({ ctx, next }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return next({ ctx });
      })
      .input(
        z.object({
          name: z.string().min(1),
          slug: z.string().min(1),
          description: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return createCategory(input);
      }),

    update: protectedProcedure
      .use(async ({ ctx, next }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return next({ ctx });
      })
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          slug: z.string().optional(),
          description: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await updateCategory(id, data);
      }),

    delete: protectedProcedure
      .use(async ({ ctx, next }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return next({ ctx });
      })
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteCategory(input.id);
      }),
  }),

  images: router({
    // Admin procedures
    upload: protectedProcedure
      .use(async ({ ctx, next }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return next({ ctx });
      })
      .input(
        z.object({
          productId: z.number(),
          fileName: z.string(),
          fileData: z.string(), // base64 encoded file data
          mimeType: z.string(),
          altText: z.string().optional(),
          displayOrder: z.number().default(0),
        })
      )
      .mutation(async ({ input }) => {
        const storagePut = (await import("./storage")).storagePut;
        
        // Convert base64 to buffer
        const buffer = Buffer.from(input.fileData, "base64");
        
        // Upload to storage
        const { key, url } = await storagePut(
          `products/${input.productId}/${input.fileName}`,
          buffer,
          input.mimeType
        );
        
        // Save image metadata to database
        return addProductImage({
          productId: input.productId,
          imageUrl: url,
          imageKey: key,
          altText: input.altText,
          displayOrder: input.displayOrder,
        });
      }),

    add: protectedProcedure
      .use(async ({ ctx, next }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return next({ ctx });
      })
      .input(
        z.object({
          productId: z.number(),
          imageUrl: z.string().url(),
          imageKey: z.string(),
          altText: z.string().optional(),
          displayOrder: z.number().default(0),
        })
      )
      .mutation(async ({ input }) => {
        return addProductImage(input);
      }),

    delete: protectedProcedure
      .use(async ({ ctx, next }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return next({ ctx });
      })
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteProductImage(input.id);
      }),
  }),
});

export type AppRouter = typeof appRouter;
