import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, categories, InsertCategory, products, InsertProduct, productImages, InsertProductImage } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get user by ID
 */
export async function getUserById(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get all categories
 */
export async function getCategories() {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(categories);
}

/**
 * Get category by ID
 */
export async function getCategoryById(categoryId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(categories).where(eq(categories.id, categoryId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get products with first image in optimized single query
 */
export async function getProducts(filters?: { categoryId?: number; isFeatured?: boolean; isSoldOut?: boolean }) {
  const db = await getDb();
  if (!db) return [];
  
  const conditions = [];
  
  if (filters?.categoryId) {
    conditions.push(eq(products.categoryId, filters.categoryId));
  }
  if (filters?.isFeatured !== undefined) {
    conditions.push(eq(products.isFeatured, filters.isFeatured ? 1 : 0));
  }
  if (filters?.isSoldOut !== undefined) {
    conditions.push(eq(products.isSoldOut, filters.isSoldOut ? 1 : 0));
  }
  
  // Optimized single query with join to get first image
  let query: any = db
    .select({
      product: products,
      firstImage: productImages,
    })
    .from(products)
    .leftJoin(
      productImages,
      and(
        eq(productImages.productId, products.id),
        eq(productImages.displayOrder, 0)
      )
    );
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions));
  }
  
  const results = await query;
  
  const productMap = new Map();
  results.forEach((row: any) => {
    if (!productMap.has(row.product.id)) {
      productMap.set(row.product.id, {
        ...row.product,
        firstImage: row.firstImage || null,
      });
    }
  });
  
  return Array.from(productMap.values());
}

/**
 * Get product by ID with images
 */
export async function getProductWithImages(productId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const product = await db.select().from(products).where(eq(products.id, productId)).limit(1);
  if (!product.length) return undefined;
  
  const images = await db.select().from(productImages).where(eq(productImages.productId, productId)).orderBy(productImages.displayOrder);
  
  return {
    ...product[0],
    images,
  };
}

/**
 * Create a new product
 */
export async function createProduct(data: InsertProduct) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(products).values(data);
  return result;
}

/**
 * Update a product
 */
export async function updateProduct(productId: number, data: Partial<InsertProduct>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.update(products).set(data).where(eq(products.id, productId));
}

/**
 * Delete a product
 */
export async function deleteProduct(productId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Delete images first
  await db.delete(productImages).where(eq(productImages.productId, productId));
  
  // Then delete product
  return db.delete(products).where(eq(products.id, productId));
}

/**
 * Add product image
 */
export async function addProductImage(data: InsertProductImage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(productImages).values(data);
}

/**
 * Delete product image
 */
export async function deleteProductImage(imageId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.delete(productImages).where(eq(productImages.id, imageId));
}

/**
 * Get product images
 */
export async function getProductImages(productId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(productImages).where(eq(productImages.productId, productId)).orderBy(productImages.displayOrder);
}

/**
 * Create a new category
 */
export async function createCategory(data: InsertCategory) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(categories).values(data);
}

/**
 * Update a category
 */
export async function updateCategory(categoryId: number, data: Partial<InsertCategory>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.update(categories).set(data).where(eq(categories.id, categoryId));
}

/**
 * Delete a category
 */
export async function deleteCategory(categoryId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.delete(categories).where(eq(categories.id, categoryId));
}
